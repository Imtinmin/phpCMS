<?php

$lang['member_auth_fail'] = '实名认证审核未通过';
$lang['member_idcard'] = '身份证号';
$lang['member_idcard_image1'] = '手持身份证照片';
$lang['member_idcard_image2'] = '身份证正面照片';
$lang['member_idcard_image3'] = '身份证反面照片';
$lang['checkbox_empty'] = '请勾选选项';
$lang['refuse_reason'] = '请勾选选项';
$lang['member_idcard'] = '身份证号';
$lang['member_idcard'] = '身份证号';
$lang['member_auth_state'][1] = '审核中';
$lang['member_auth_state'][2] = '未通过';
$lang['member_auth_state'][3] = '已认证';