<?php

$lang['delivery_truename'] = '真实姓名';
$lang['delivery_index_help1'] = '提示：自提服务站关闭后，被用户设置成收货地址的记录会被删除，请谨慎操作。';
$lang['delivery_index_username'] = '用户名';
$lang['delivery_index_address'] = '收货地址';
$lang['delivery_add_time'] = '申请时间';
$lang['delivery_index_view_order'] = '查看订单';
$lang['delivery_username'] = '自提服务站用户名';

$lang['delivery_mob_phone'] = '手机号';
$lang['delivery_telephone'] = '座机号';
$lang['delivery_name'] = '自提服务站名称';
$lang['delivery_idcard'] = '身份证号码';
$lang['delivery_idcardimage'] = '身份证图片';
$lang['delivery_idcardimage_tips'] = '点击查看大图';
$lang['delivery_add_time'] = '登录密码';
$lang['delivery_passwd_tips'] = '不填为不修改密码';
$lang['delivery_fail_reason'] = '审核失败原因';

$lang['delivery_ship_code'] = '运单号';
$lang['delivery_consignee'] = '收货人';
$lang['delivery_is_open'] = '自提服务站是否开启';
$lang['delivery_set_express'] = '现在去设置自提服务站使用的快递公司，';

$lang['delivery_verify'] = '等待审核';



