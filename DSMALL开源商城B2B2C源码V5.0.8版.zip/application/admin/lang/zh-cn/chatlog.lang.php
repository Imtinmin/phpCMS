<?php

$lang['chatlog_f_name'] = '发送人';
$lang['chatlog_t_name'] = '回复人';
$lang['chatlog_start_to_stop_time'] = '起止时间';
$lang['chatlog_index_help1'] = '发送人即发出消息的会员，回复人为收到消息的会员，如果是店铺的客服或管理员可显示所属店铺名称';
$lang['chatlog_index_help2'] = '为使查询信息更准确，建议您输入聊天双方的完整会员名（登录账号）';
$lang['chatlog_index_help3'] = '当前可查询';
$lang['chatlog_index_help4'] = '至';
$lang['chatlog_index_help5'] = '的90天内的聊天记录内容';
$lang['chatlog_consult'] = '客服';
$lang['chatlog_keywords'] = '关键字';
$lang['chatlog_msglog_help1'] = '根据“关键字”查询消息，点击“详情”可查看当天的所有对话。';
$lang['chatlog_f_name_member'] = '发消息会员';
$lang['chatlog_t_name_member'] = '接收消息会员';
$lang['chatlog_detail'] = '详情';
$lang['chatlog_content'] = '聊天内容';