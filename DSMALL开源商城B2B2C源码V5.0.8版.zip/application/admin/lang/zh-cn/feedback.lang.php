<?php

/**
 * 意见反馈
 */
$lang['feedback_index_content'] = '反馈内容';
$lang['feedback_index_time'] = '时间';
$lang['feedback_index_from'] = '来自';
$lang['feedback_index_hlpe1'] = '用户的反馈';

?>
