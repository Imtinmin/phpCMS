<?php
$lang['bonus_id'] = '红包ID';
$lang['bonus_type'] = '红包类型';
$lang['bonus_name'] = '红包名称';
$lang['bonus_name_error'] = '红包名称错误';
$lang['bonus_blessing'] = '红包祝福语';
$lang['bonus_totalprice'] = '红包总面额';
$lang['bonus_pricetype'] = '是否固定金额';
$lang['bonus_pricetype'] = '是否固定金额';
$lang['bonus_pricetype_0'] = '随机金额';
$lang['bonus_pricetype_1'] = '固定金额';
$lang['bonus_fixedprice'] = '固定金额';
$lang['bonus_randomprice_start'] = '最小金额';
$lang['bonus_randomprice_end'] = '最大金额';
$lang['bonus_receivecount'] = '领取人数';
$lang['bonus_receiveprice'] = '领取金额';
$lang['bonus_state'] = '红包状态';

$lang['bonus_remark'] = '红包备注';
$lang['bonusreceive_time'] = '领取时间';
$lang['bonusreceive_price'] = '领取金额';
$lang['bonusreceive_transformed'] = '是否转入预存款';

$lang['bonus_randomprice_error']='随机金额或红包总面额错误';

$lang['bonus_fixedprice_error']='固定金额或红包总面额错误';