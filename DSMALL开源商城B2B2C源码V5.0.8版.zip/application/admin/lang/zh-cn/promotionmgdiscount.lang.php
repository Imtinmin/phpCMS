<?php

$lang['mgdiscount_store'] = '店铺折扣';
$lang['mgdiscount_goods'] = '商品折扣';
$lang['mgdiscount_setting'] = '折扣设置';
$lang['store_user_name'] = '店铺用户名';
$lang['store_mgdiscount_state'] = '开启会员折扣';
$lang['store_mgdiscount_arr'] = '店铺折扣';

$lang['goods_mgdiscount_arr'] = '商品折扣';



$lang['mgdiscount_price'] = '会员等级折扣套餐价格';
$lang['mgdiscount_price_explain'] = '购买单位为月(30天)，购买后卖家可以在所购买周期内发布会员等级折扣活动';


$lang['setting_save_success'] = '设置保存成功';
$lang['setting_save_fail'] = '设置保存失败';

$lang['level_discount'] = '折';