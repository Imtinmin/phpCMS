<?php
$lang['default_goods_image'] = '默认商品图片:';
$lang['default_store_logo'] = '默认店铺标志:';
$lang['default_store_avatar'] = '默认店铺头像:';
$lang['default_user_portrait'] = '默认会员头像';
$lang['default_thumb'] = '默认图片';
$lang['upload_type']  = '商品图片存储方式';
$lang['upload_type_local'] = '本地存储';
$lang['upload_type_alioss'] ='阿里云OSS存储';
$lang['alioss_accessid'] = '阿里云OssAccessKeyId';
$lang['alioss_accesssecret'] ='阿里云OssSecretAccess';
$lang['alioss_bucket']='阿里云OssBucket';
$lang['alioss_endpoint'] ='阿里云OssEndpoint';
$lang['aliendpoint_type'] ='阿里云OssEndpoint是否CNAME指向域名';
$lang['config_document'] ='配置文档';

$lang['suggest_picture_pixel'] ='建议上传图片像素为';

$lang['upload_set'] ='上传设置';