<?php

$lang['admin_log'] = '操作日志';
$lang['admin_log_man'] = '操作人';
$lang['admin_log_do'] = '行为';
$lang['admin_log_dotime'] = '时间';
$lang['admin_log_tips2'] = '开启操作日志会记录管理员的操作，但会轻微加重系统负担，所以请您权衡利弊';
