<?php
return array(
    // 应用版本
    'app_version' => '2.0.7',
    
    // 发布时间
    'release_time' => '20200406',
    
    // 修订版本
    'revise_version' => '0'

);
